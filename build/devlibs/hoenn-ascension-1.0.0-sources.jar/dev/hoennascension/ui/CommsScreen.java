package dev.hoennascension.ui;

import dev.hoennascension.HoennAscensionClient;
import dev.hoennascension.config.ChannelDef;
import dev.hoennascension.config.HoennConfig;
import dev.hoennascension.core.ChatEntry;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Panel principal: movible (arrastrando la cabecera o el logo), redimensionable (bordes derecho,
 * inferior y esquina), adaptable al tamaño de pantalla, con bandera plegable.
 */
public final class CommsScreen extends Screen {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static final int LINE_H = 10;
    private static final int MIN_W = 280;
    private static final int MIN_H = 150;
    private static final int MARGIN = 4;
    private static final int HEADER_H = 24;
    private static final int EDGE = 5;

    private record Line(OrderedText text, int rgb, boolean mention) {}

    private final List<Line> lines = new ArrayList<>();
    private final List<String> tabIds = new ArrayList<>();

    private String activeTab = "all";
    private int scroll = 0;

    private int cacheVersion = -1;
    private int cacheWidth = -1;
    private String cacheTab = "";
    private String cacheFilter = "";

    // Ventana
    private int px, py, pw, ph;
    private boolean minimizing = false;

    // Arrastre y redimensionado
    private boolean dragging;
    private int dragOffX, dragOffY;
    private int resizeMode; // bit 1 = borde derecho, bit 2 = borde inferior
    private int resizeStartMx, resizeStartMy, resizeStartW, resizeStartH;
    private long lastHeaderClick;

    // Cabecera (se recalcula según el ancho disponible)
    private int closeX, minX, pinX, gearX, themeX, searchX;
    private boolean showTheme, showSearch;

    // Decoración
    private boolean showLogo;
    private int logoX, logoY, logoW, logoH;
    private int bannerX, bannerY, bannerW, bannerH;
    private float bannerAnim = 1f;
    private long lastFrame;

    private TextFieldWidget input;
    private TextFieldWidget search;

    public CommsScreen() {
        super(Text.translatable("hoennascension.title"));
    }

    // ---- Layout -------------------------------------------------------------------------

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private int listTop() { return py + 46; }
    private int listBottom() { return py + ph - 26; }
    private int visibleLines() { return Math.max(1, (listBottom() - listTop()) / LINE_H); }
    private int btnY() { return py + 5; }
    private int sendX() { return px + pw - 26; }

    private void applyInitialLayout(HoennConfig cfg) {
        if (cfg.winW > 0 && cfg.winH > 0) {
            pw = clamp(cfg.winW, MIN_W, Math.max(MIN_W, width - 2 * MARGIN));
            ph = clamp(cfg.winH, MIN_H, Math.max(MIN_H, height - 2 * MARGIN));
            px = clamp(cfg.winX, MARGIN, Math.max(MARGIN, width - pw - MARGIN));
            py = clamp(cfg.winY, MARGIN, Math.max(MARGIN, height - ph - MARGIN));
        } else {
            pw = clamp(Math.min(width - 24, 460), MIN_W, Math.max(MIN_W, width - 2 * MARGIN));
            boolean room = cfg.showLogo && height >= 300;
            int lw = Math.min(220, pw);
            int lh = lw * Art.LOGO_H / Art.LOGO_W;
            int extra = room ? lh + 2 : 0;
            ph = clamp(Math.min(height - 24 - extra, 290), MIN_H, Math.max(MIN_H, height - 2 * MARGIN));
            px = (width - pw) / 2;
            py = (height - (ph + extra)) / 2 + extra;
        }
    }

    private void storeLayout(HoennConfig cfg) {
        cfg.winX = px;
        cfg.winY = py;
        cfg.winW = pw;
        cfg.winH = ph;
    }

    /** Coloca los botones de la cabecera de derecha a izquierda y oculta los que no caben. */
    private void computeHeader() {
        TextRenderer tr = textRenderer;
        int titleEnd = px + 24 + tr.getWidth(title) + 10;
        int x = px + pw - 6;
        closeX = x - 14;
        x = closeX - 2;
        minX = x - 14;
        x = minX - 2;
        pinX = x - 14;
        x = pinX - 2;
        gearX = x - 14;
        x = gearX - 4;
        showTheme = x - 58 >= titleEnd;
        if (showTheme) {
            themeX = x - 58;
            x = themeX - 4;
        }
        showSearch = x - 80 >= titleEnd;
        if (showSearch) searchX = x - 80;
    }

    private void layoutWidgets() {
        input.setX(px + 12);
        input.setY(py + ph - 18);
        input.setWidth(Math.max(20, pw - 44));
        search.visible = showSearch;
        search.active = showSearch;
        if (showSearch) {
            search.setX(searchX + 4);
            search.setY(py + 8);
            search.setWidth(72);
        } else if (!search.getText().isEmpty()) {
            search.setText("");
        }
    }

    private void layoutDecor(HoennConfig cfg) {
        logoW = Math.min(220, pw);
        logoH = logoW * Art.LOGO_H / Art.LOGO_W;
        showLogo = cfg.showLogo && py >= logoH + 2;
        logoX = px + (pw - logoW) / 2;
        logoY = py - logoH - 2;

        int overlap = 4;
        int peek = 9;
        int bw = Math.min(72, Math.max(36, ph / 4));
        bw = Math.min(bw, px + overlap);
        int bh = bw * Art.BANNER_H / Art.BANNER_W;
        bannerY = py + 6;
        int maxH = height - bannerY - 2;
        if (bh > maxH) {
            bh = maxH;
            bw = bh * Art.BANNER_W / Art.BANNER_H;
        }
        if (!cfg.showBanner || bw < 28) {
            bannerW = 0;
            bannerH = 0;
            return;
        }
        bannerW = bw;
        bannerH = bh;
        int visibleX = px + overlap - bw;
        int hiddenX = px - peek;
        bannerX = Math.round(hiddenX + (visibleX - hiddenX) * bannerAnim);
    }

    private boolean overBanner(double mx, double my) {
        return bannerW > 0 && Gfx.inside(mx, my, bannerX, bannerY, Math.min(bannerW, px - bannerX), bannerH);
    }

    @Override
    protected void init() {
        HoennConfig cfg = HoennConfig.get();
        cfg.minimized = false;

        tabIds.clear();
        tabIds.add("all");
        for (ChannelDef c : cfg.channels) tabIds.add(c.id);
        if (!tabIds.contains(activeTab)) activeTab = "all";

        applyInitialLayout(cfg);

        input = new TextFieldWidget(textRenderer, px + 12, py + ph - 18, pw - 44, 12, Text.empty());
        input.setMaxLength(256);
        input.setDrawsBackground(false);
        input.setPlaceholder(Text.translatable("hoennascension.input.placeholder"));
        addDrawableChild(input);

        search = new TextFieldWidget(textRenderer, 0, py + 8, 72, 12, Text.empty());
        search.setMaxLength(48);
        search.setDrawsBackground(false);
        search.setPlaceholder(Text.translatable("hoennascension.search.placeholder"));
        search.setChangedListener(s -> {
            cacheVersion = -1;
            scroll = 0;
        });
        addDrawableChild(search);

        bannerAnim = cfg.bannerHidden ? 0f : 1f;
        lastFrame = System.currentTimeMillis();
        computeHeader();
        layoutWidgets();

        setInitialFocus(input);
        HoennAscensionClient.STORE.markRead(activeTab);
    }

    private void resetLayout() {
        HoennConfig cfg = HoennConfig.get();
        cfg.resetLayout();
        cfg.save();
        clearAndInit();
    }

    // ---- Datos --------------------------------------------------------------------------

    private String tabName(String id) {
        if (id.equals("all")) return Text.translatable("hoennascension.tab.all").getString();
        ChannelDef c = HoennConfig.get().channel(id);
        return c == null ? id : c.name;
    }

    private void rebuildIfNeeded(Theme th) {
        String filter = search.getText().trim().toLowerCase(Locale.ROOT);
        int version = HoennAscensionClient.STORE.version;
        if (version == cacheVersion && pw == cacheWidth && activeTab.equals(cacheTab)
                && filter.equals(cacheFilter)) return;

        cacheVersion = version;
        cacheWidth = pw;
        cacheTab = activeTab;
        cacheFilter = filter;
        lines.clear();

        HoennConfig cfg = HoennConfig.get();
        int wrapW = Math.max(40, pw - 28);
        for (ChatEntry e : HoennAscensionClient.STORE.view(activeTab, filter, 400)) {
            ChannelDef ch = cfg.channel(e.channel);
            int rgb = ch != null ? ch.rgb() : 0xFFFFFF;
            MutableText t = Text.empty();
            if (cfg.timestamps) {
                String time = LocalTime.ofInstant(Instant.ofEpochMilli(e.time), ZoneId.systemDefault()).format(TIME);
                t.append(Text.literal(time + " ").setStyle(Style.EMPTY.withColor(th.muted & 0xFFFFFF)));
            }
            if (activeTab.equals("all") && ch != null) {
                t.append(Text.literal("[" + ch.name + "] ").setStyle(Style.EMPTY.withColor(rgb)));
            }
            t.append(Text.literal(e.text));
            for (OrderedText ot : textRenderer.wrapLines(t, wrapW)) lines.add(new Line(ot, rgb, e.mention));
        }
    }

    private void selectTab(String id) {
        activeTab = id;
        scroll = 0;
        cacheVersion = -1;
        HoennAscensionClient.STORE.markRead(id);
    }

    private void cycleTab(int dir) {
        int i = tabIds.indexOf(activeTab);
        i = (i + dir + tabIds.size()) % tabIds.size();
        selectTab(tabIds.get(i));
    }

    private void send() {
        String s = input.getText().trim();
        if (s.isEmpty() || client == null || client.player == null) return;
        ChannelDef ch = HoennConfig.get().channel(activeTab);
        String prefix = (ch != null && ch.sendPrefix != null) ? ch.sendPrefix : "";
        String full = s.startsWith("/") ? s : prefix + s;
        ClientPlayNetworkHandler net = client.player.networkHandler;
        if (full.startsWith("/")) net.sendChatCommand(full.substring(1));
        else net.sendChatMessage(full);
        input.setText("");
        scroll = 0;
    }

    // ---- Render -------------------------------------------------------------------------

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
        // Intencionalmente vacío: sin blur vanilla; el oscurecido se dibuja en render().
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        HoennConfig cfg = HoennConfig.get();
        Theme th = Theme.byId(cfg.theme);
        TextRenderer tr = textRenderer;

        // Animación de la bandera (suavizado exponencial)
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        float target = cfg.bannerHidden ? 0f : 1f;
        bannerAnim += (target - bannerAnim) * Math.min(1f, dt * 12f);
        if (Math.abs(target - bannerAnim) < 0.004f) bannerAnim = target;

        computeHeader();
        layoutWidgets();
        layoutDecor(cfg);

        c.fill(0, 0, width, height, 0x44000000);

        // Bandera: se recorta en el borde del panel para que parezca que se guarda detrás
        if (bannerW > 0) {
            c.enableScissor(0, 0, px + 4, height);
            Art.draw(c, Art.BANNER, bannerX, bannerY, bannerW, bannerH, Art.BANNER_W, Art.BANNER_H,
                    0.6f + 0.4f * bannerAnim);
            c.disableScissor();
        }

        Gfx.panel(c, px, py, pw, ph, th, cfg.menuOpacity);
        if (showLogo) Art.draw(c, Art.LOGO, logoX, logoY, logoW, logoH, Art.LOGO_W, Art.LOGO_H, 1f);

        HoennAscensionClient.STORE.markRead(activeTab);
        rebuildIfNeeded(th);

        // Cabecera
        Gfx.diamond(c, px + 13, py + 12, 4, th.edgeAt(0.5f));
        Gfx.diamondOutline(c, px + 13, py + 12, 6, th.edgeAt(0.15f));
        c.drawText(tr, title, px + 24, py + 8, th.text, true);
        Gfx.hBand(c, px + 1, py + 23, px + pw - 1, py + 24, th, 0.6f, 0f, 1f);

        if (showSearch) c.fill(searchX, py + 4, searchX + 80, py + 18, 0x55000000);

        boolean hoverTheme = showTheme && Gfx.inside(mx, my, themeX, btnY(), 58, 14);
        if (showTheme) {
            c.fillGradient(themeX, btnY(), themeX + 58, btnY() + 14,
                    Gfx.alpha(th.edgeA, hoverTheme ? 0.9f : 0.5f), Gfx.alpha(th.edgeC, hoverTheme ? 0.9f : 0.5f));
            c.drawText(tr, th.label, themeX + 29 - tr.getWidth(th.label) / 2, btnY() + 3, th.text, false);
        }

        // Ajustes (tres deslizadores)
        boolean hoverGear = Gfx.inside(mx, my, gearX, btnY(), 14, 14);
        int gc = hoverGear ? th.text : th.muted;
        for (int i = 0; i < 3; i++) {
            int gy = btnY() + 3 + i * 4;
            c.fill(gearX + 2, gy, gearX + 12, gy + 1, gc);
            int kx = gearX + 3 + ((i * 4) % 7);
            c.fill(kx, gy - 1, kx + 2, gy + 2, gc);
        }

        // Anclar
        boolean hoverPin = Gfx.inside(mx, my, pinX, btnY(), 14, 14);
        if (cfg.hudPinned) Gfx.diamond(c, pinX + 7, btnY() + 7, 5, th.edgeAt(0.5f));
        else Gfx.diamondOutline(c, pinX + 7, btnY() + 7, 5, hoverPin ? th.text : th.muted);

        // Minimizar
        boolean hoverMin = Gfx.inside(mx, my, minX, btnY(), 14, 14);
        c.fill(minX + 3, btnY() + 9, minX + 11, btnY() + 11, hoverMin ? th.text : th.muted);

        // Cerrar
        boolean hoverClose = Gfx.inside(mx, my, closeX, btnY(), 14, 14);
        c.drawText(tr, "x", closeX + 5, btnY() + 3, hoverClose ? 0xFFFF6A6A : th.muted, false);

        // Pestañas
        int tabY = py + 26;
        int count = tabIds.size();
        int tabW = Math.max(1, (pw - 16) / count);
        for (int i = 0; i < count; i++) {
            String id = tabIds.get(i);
            int x = px + 8 + i * tabW;
            boolean active = id.equals(activeTab);
            boolean hover = Gfx.inside(mx, my, x, tabY, tabW, 16);
            ChannelDef ch = id.equals("all") ? null : cfg.channel(id);
            int rgb = ch != null ? ch.rgb() : 0xFFFFFF;

            if (active) {
                c.fillGradient(x, tabY, x + tabW, tabY + 16, Gfx.rgb(rgb, 0.0f), Gfx.rgb(rgb, 0.28f));
                if (ch == null) Gfx.hBand(c, x, tabY + 14, x + tabW, tabY + 16, th, 1f,
                        i / (float) count, (i + 1) / (float) count);
                else c.fill(x, tabY + 14, x + tabW, tabY + 16, Gfx.rgb(rgb, 1f));
            } else if (hover) {
                c.fill(x, tabY, x + tabW, tabY + 16, 0x22FFFFFF);
            }

            int unread = id.equals(activeTab) ? 0 : HoennAscensionClient.STORE.unread(id);
            String badge = unread > 0 ? (unread > 99 ? "99+" : String.valueOf(unread)) : "";
            int badgeW = badge.isEmpty() ? 0 : tr.getWidth(badge) + 4;

            Gfx.diamond(c, x + 7, tabY + 7, 2, ch != null ? Gfx.rgb(rgb, active ? 1f : 0.7f) : th.edgeAt(0.5f));
            String label = tr.trimToWidth(tabName(id), Math.max(0, tabW - 16 - badgeW));
            c.drawText(tr, label, x + 13, tabY + 4, active ? th.text : th.muted, true);
            if (!badge.isEmpty()) {
                int bx = x + tabW - badgeW - 1;
                c.fill(bx, tabY + 3, bx + badgeW, tabY + 12, Gfx.rgb(rgb, 0.85f));
                c.drawText(tr, badge, bx + 2, tabY + 4, 0xFFFFFFFF, false);
            }
        }

        // Lista de mensajes
        int lt = listTop();
        int lb = listBottom();
        int vis = visibleLines();
        int maxScroll = Math.max(0, lines.size() - vis);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        c.fill(px + 4, lt - 2, px + pw - 4, lb + 2, 0x22000000);
        c.enableScissor(px + 4, lt - 2, px + pw - 4, lb + 2);
        int y = lb - LINE_H;
        for (int idx = lines.size() - 1 - scroll; idx >= 0 && y > lt - LINE_H; idx--, y -= LINE_H) {
            Line l = lines.get(idx);
            if (l.mention()) c.fill(px + 6, y - 1, px + pw - 10, y + 9, Gfx.alpha(th.edgeB, 0.30f));
            c.fill(px + 6, y - 1, px + 8, y + 9, Gfx.rgb(l.rgb(), 0.9f));
            c.drawText(tr, l.text(), px + 12, y, th.text, true);
        }
        c.disableScissor();

        // Barra de scroll
        if (lines.size() > vis) {
            int trackH = lb - lt;
            int thumbH = Math.max(8, trackH * vis / lines.size());
            float frac = maxScroll == 0 ? 0f : scroll / (float) maxScroll;
            int thumbY = lb - thumbH - (int) ((trackH - thumbH) * frac);
            c.fill(px + pw - 8, lt, px + pw - 6, lb, 0x33FFFFFF);
            c.fillGradient(px + pw - 8, thumbY, px + pw - 6, thumbY + thumbH,
                    Gfx.alpha(th.edgeA, 1f), Gfx.alpha(th.edgeC, 1f));
        }

        // Barra de entrada
        int ib = py + ph - 22;
        c.fill(px + 8, ib, px + pw - 8, ib + 16, 0x55000000);
        Gfx.hBand(c, px + 8, ib, px + pw - 8, ib + 1, th, 0.8f, 0f, 1f);
        boolean hoverSend = Gfx.inside(mx, my, sendX(), ib, 18, 16);
        Gfx.diamond(c, sendX() + 9, ib + 8, 4, hoverSend ? 0xFFFFFFFF : th.edgeAt(0.85f));

        // Agarre de redimensionado (esquina inferior derecha)
        boolean hoverGrip = Gfx.inside(mx, my, px + pw - EDGE - 6, py + ph - EDGE - 6, EDGE + 8, EDGE + 8);
        int grip = hoverGrip || resizeMode != 0 ? th.text : th.muted;
        for (int r = 0; r < 3; r++)
            for (int k = 0; k < 3 - r; k++)
                c.fill(px + pw - 5 - k * 3, py + ph - 5 - r * 3, px + pw - 4 - k * 3, py + ph - 4 - r * 3, grip);

        super.render(c, mx, my, delta);

        // Tooltips
        boolean hoverBanner = overBanner(mx, my);
        if (hoverPin) c.drawTooltip(tr, Text.translatable(cfg.hudPinned
                ? "hoennascension.tooltip.pin.on" : "hoennascension.tooltip.pin.off"), mx, my);
        else if (hoverTheme) c.drawTooltip(tr, Text.translatable("hoennascension.tooltip.theme"), mx, my);
        else if (hoverGear) c.drawTooltip(tr, Text.translatable("hoennascension.tooltip.settings"), mx, my);
        else if (hoverMin) c.drawTooltip(tr, Text.translatable("hoennascension.tooltip.minimize"), mx, my);
        else if (hoverClose) c.drawTooltip(tr, Text.translatable("hoennascension.tooltip.close"), mx, my);
        else if (hoverBanner) c.drawTooltip(tr, Text.translatable(cfg.bannerHidden
                ? "hoennascension.tooltip.banner.show" : "hoennascension.tooltip.banner.hide"), mx, my);
    }

    // ---- Entrada ------------------------------------------------------------------------

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            HoennConfig cfg = HoennConfig.get();
            computeHeader();
            layoutDecor(cfg);

            if (Gfx.inside(mx, my, closeX, btnY(), 14, 14)) {
                close();
                return true;
            }
            if (Gfx.inside(mx, my, minX, btnY(), 14, 14)) {
                minimizing = true;
                close();
                return true;
            }
            if (Gfx.inside(mx, my, gearX, btnY(), 14, 14)) {
                if (client != null) client.setScreen(new HoennConfigScreen(this));
                return true;
            }
            if (Gfx.inside(mx, my, pinX, btnY(), 14, 14)) {
                cfg.hudPinned = !cfg.hudPinned;
                cfg.save();
                return true;
            }
            if (showTheme && Gfx.inside(mx, my, themeX, btnY(), 58, 14)) {
                cfg.theme = Theme.byId(cfg.theme).next().id;
                cfg.save();
                return true;
            }
            if (Gfx.inside(mx, my, sendX(), py + ph - 22, 18, 16)) {
                send();
                return true;
            }
            if (overBanner(mx, my)) {
                cfg.bannerHidden = !cfg.bannerHidden;
                cfg.save();
                return true;
            }

            // Bordes de redimensionado
            boolean onRight = mx >= px + pw - EDGE && mx <= px + pw + 2 && my >= py && my <= py + ph + 2;
            boolean onBottom = my >= py + ph - EDGE && my <= py + ph + 2 && mx >= px && mx <= px + pw + 2;
            if (onRight || onBottom) {
                resizeMode = (onRight ? 1 : 0) | (onBottom ? 2 : 0);
                resizeStartMx = (int) mx;
                resizeStartMy = (int) my;
                resizeStartW = pw;
                resizeStartH = ph;
                return true;
            }

            int tabY = py + 26;
            int tabW = Math.max(1, (pw - 16) / tabIds.size());
            for (int i = 0; i < tabIds.size(); i++) {
                if (Gfx.inside(mx, my, px + 8 + i * tabW, tabY, tabW, 16)) {
                    selectTab(tabIds.get(i));
                    return true;
                }
            }

            // Arrastrar desde la cabecera o el logo; doble clic = restaurar posición y tamaño
            boolean inHeader = Gfx.inside(mx, my, px, py, pw, HEADER_H)
                    && !(showSearch && Gfx.inside(mx, my, searchX, py + 4, 80, 14));
            boolean inLogo = showLogo && Gfx.inside(mx, my, logoX, logoY, logoW, logoH);
            if (inHeader || inLogo) {
                long now = System.currentTimeMillis();
                if (now - lastHeaderClick < 300) {
                    lastHeaderClick = 0;
                    resetLayout();
                    return true;
                }
                lastHeaderClick = now;
                dragging = true;
                dragOffX = (int) mx - px;
                dragOffY = (int) my - py;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0) {
            HoennConfig cfg = HoennConfig.get();
            if (dragging) {
                px = clamp((int) mx - dragOffX, MARGIN, Math.max(MARGIN, width - pw - MARGIN));
                py = clamp((int) my - dragOffY, MARGIN, Math.max(MARGIN, height - ph - MARGIN));
                storeLayout(cfg);
                return true;
            }
            if (resizeMode != 0) {
                if ((resizeMode & 1) != 0)
                    pw = clamp(resizeStartW + (int) mx - resizeStartMx, MIN_W, Math.max(MIN_W, width - px - MARGIN));
                if ((resizeMode & 2) != 0)
                    ph = clamp(resizeStartH + (int) my - resizeStartMy, MIN_H, Math.max(MIN_H, height - py - MARGIN));
                storeLayout(cfg);
                return true;
            }
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0 && (dragging || resizeMode != 0)) {
            dragging = false;
            resizeMode = 0;
            HoennConfig.get().save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (vertical != 0) {
            scroll += (int) Math.signum(vertical) * 3;
            if (scroll < 0) scroll = 0;
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if ((keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) && input.isFocused()) {
            send();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_PAGE_UP) {
            scroll += visibleLines();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_PAGE_DOWN) {
            scroll = Math.max(0, scroll - visibleLines());
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_TAB) {
            cycleTab(hasShiftDown() ? -1 : 1);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        HoennConfig.get().minimized = minimizing;
        HoennConfig.get().save();
        HoennAscensionClient.STORE.save();
    }
}