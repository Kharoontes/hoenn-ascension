package dev.hoennascension.ui;

import dev.hoennascension.HoennAscensionClient;
import dev.hoennascension.config.ChannelDef;
import dev.hoennascension.config.HoennConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Notificaciones apiladas arriba a la derecha, con acciones aceptar/rechazar opcionales. */
public final class PopupManager {
    private static final int W = 196;
    private static final int MAX_VISIBLE = 4;

    private static final class Popup {
        String title;
        String body;
        String accept;
        String deny;
        int rgb;
        long born;
        long life;

        boolean actionable() {
            return accept != null && !accept.isBlank();
        }
    }

    private final List<Popup> popups = new ArrayList<>();

    public void push(String title, String body, ChannelDef ch) {
        HoennConfig cfg = HoennConfig.get();
        Popup p = new Popup();
        p.title = title;
        p.body = body.length() > 140 ? body.substring(0, 137) + "..." : body;
        p.rgb = ch.rgb();
        p.born = System.currentTimeMillis();
        if (ch.isActionable()) {
            p.accept = ch.acceptCommand;
            p.deny = ch.denyCommand;
            p.life = cfg.actionPopupSeconds * 1000L;
        } else {
            p.life = cfg.popupSeconds * 1000L;
        }
        popups.add(p);
        while (popups.size() > 8) popups.remove(0);
    }

    public void clear() {
        popups.clear();
    }

    /** Se llama cada tick: caducidad y teclas de acción. */
    public void tick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        popups.removeIf(p -> now - p.born > p.life);

        while (HoennAscensionClient.ACCEPT.wasPressed()) runAction(mc, true);
        while (HoennAscensionClient.DENY.wasPressed()) runAction(mc, false);
    }

    private void runAction(MinecraftClient mc, boolean accept) {
        Popup target = null;
        for (int i = popups.size() - 1; i >= 0; i--) {
            if (popups.get(i).actionable()) {
                target = popups.get(i);
                break;
            }
        }
        if (target == null || mc.player == null) return;
        String cmd = accept ? target.accept : target.deny;
        popups.remove(target);
        if (cmd == null || cmd.isBlank()) return;
        mc.player.networkHandler.sendChatCommand(cmd.startsWith("/") ? cmd.substring(1) : cmd);
    }

    public void render(DrawContext c) {
        if (popups.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        HoennConfig cfg = HoennConfig.get();
        Theme th = Theme.byId(cfg.theme);
        TextRenderer tr = mc.textRenderer;
        int sw = c.getScaledWindowWidth();
        long now = System.currentTimeMillis();

        int start = Math.max(0, popups.size() - MAX_VISIBLE);
        int y = 6;
        for (int i = start; i < popups.size(); i++) {
            Popup p = popups.get(i);
            long age = now - p.born;
            long left = p.life - age;

            float slide = Math.min(1f, age / 250f);
            slide = 1f - (1f - slide) * (1f - slide);
            float fade = left < 300 ? Math.max(0f, left / 300f) : 1f;
            int x = sw - W - 6 + (int) ((1f - slide) * (W + 12));

            List<OrderedText> lines = tr.wrapLines(Text.literal(p.body), W - 18);
            int shown = Math.min(2, lines.size());
            int h = 20 + shown * 10 + (p.actionable() ? 12 : 0);

            Gfx.panel(c, x, y, W, h, th, Math.min(1f, cfg.menuOpacity + 0.2f) * fade);
            // Barra lateral del color del canal
            c.fill(x + 1, y + 1, x + 4, y + h - 1, Gfx.rgb(p.rgb, fade));
            Gfx.diamond(c, x + 12, y + 8, 3, Gfx.rgb(p.rgb, fade));
            c.drawText(tr, p.title, x + 20, y + 5, Gfx.alpha(th.text, fade), true);

            int ty = y + 16;
            for (int l = 0; l < shown; l++) {
                c.drawText(tr, lines.get(l), x + 10, ty, Gfx.alpha(0xFFD5DCF5, fade), false);
                ty += 10;
            }
            if (p.actionable()) {
                Text acc = Text.literal("[").append(HoennAscensionClient.ACCEPT.getBoundKeyLocalizedText())
                        .append("] ").append(Text.translatable("hoennascension.popup.accept"));
                Text den = Text.literal("[").append(HoennAscensionClient.DENY.getBoundKeyLocalizedText())
                        .append("] ").append(Text.translatable("hoennascension.popup.deny"));
                c.drawText(tr, acc, x + 10, ty + 1, Gfx.alpha(0xFF7DFFB0, fade), false);
                c.drawText(tr, den, x + 20 + tr.getWidth(acc), ty + 1, Gfx.alpha(0xFFFF8A8A, fade), false);
            }
            y += h + 4;
        }
    }
}