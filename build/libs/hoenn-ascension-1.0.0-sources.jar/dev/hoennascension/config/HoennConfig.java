package dev.hoennascension.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class HoennConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static HoennConfig instance;

    public int version = 1;

    // Apariencia
    /** kyogre | groudon | primal */
    public String theme = "primal";
    public boolean timestamps = true;
    /** Opacidad del fondo de los menús (0.15 = muy transparente, 1 = sólido). */
    public float menuOpacity = 0.55f;
    public boolean showLogo = true;
    public boolean showBanner = true;
    /** Bandera plegada (queda asomando una tira para volver a desplegarla). */
    public boolean bannerHidden = false;

    // Posición y tamaño de la ventana (-1 = automático/centrado)
    public int winX = -1, winY = -1, winW = -1, winH = -1;
    // Posición de la pastilla minimizada (-1 = según minimizedAnchor)
    public int pillX = -1, pillY = -1;

    // Ventana minimizada (pastilla flotante)
    public boolean minimized = false;
    /** top_left | top_right | bottom_left | bottom_right */
    public String minimizedAnchor = "top_left";

    // HUD anclado
    public boolean hudPinned = true;
    /** top_left | top_right | bottom_left | bottom_right */
    public String hudAnchor = "bottom_left";
    public int hudLines = 6;
    public int hudWidth = 260;
    public float hudOpacity = 0.65f;
    public int hudFadeSeconds = 12;
    public boolean hudAlwaysVisible = false;
    /** id de canal o "all" */
    public String hudChannel = "all";

    // Popups
    public boolean popups = true;
    public int popupSeconds = 6;
    public int actionPopupSeconds = 15;

    // Menciones
    public boolean mentionHighlight = true;
    public List<String> highlightWords = new ArrayList<>();

    public int historyPerChannel = 300;

    public List<ChannelDef> channels = new ArrayList<>();

    public static HoennConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    public static HoennConfig reload() {
        instance = load();
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("hoennascension.json");
    }

    private static HoennConfig load() {
        HoennConfig cfg = null;
        Path p = path();
        if (Files.exists(p)) {
            try {
                cfg = GSON.fromJson(Files.readString(p), HoennConfig.class);
            } catch (Exception ignored) {
                cfg = null;
            }
        }
        boolean fresh = cfg == null;
        if (fresh) cfg = new HoennConfig();
        cfg.sanitize();
        if (fresh) cfg.save();
        return cfg;
    }

    private void sanitize() {
        if (channels == null || channels.isEmpty()) channels = defaultChannels();
        if (highlightWords == null) highlightWords = new ArrayList<>();
        if (theme == null) theme = "primal";
        if (hudAnchor == null) hudAnchor = "bottom_left";
        if (minimizedAnchor == null) minimizedAnchor = "top_left";
        if (hudChannel == null) hudChannel = "all";
        hudLines = Math.max(1, Math.min(20, hudLines));
        hudWidth = Math.max(120, Math.min(600, hudWidth));
        hudOpacity = Math.max(0.05f, Math.min(1f, hudOpacity));
        menuOpacity = Math.max(0.15f, Math.min(1f, menuOpacity));
        historyPerChannel = Math.max(20, Math.min(2000, historyPerChannel));
        boolean hasFallback = false;
        for (ChannelDef c : channels) if (c.isFallback()) hasFallback = true;
        if (!hasFallback) channels.add(0, new ChannelDef("general", "General", "", "#BFD4FF"));
    }

    public void save() {
        try {
            Files.createDirectories(path().getParent());
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }

    /** Restaura posición/tamaño de la ventana, la pastilla y la bandera. */
    public void resetLayout() {
        winX = winY = winW = winH = -1;
        pillX = pillY = -1;
        bannerHidden = false;
    }

    public ChannelDef channel(String id) {
        for (ChannelDef c : channels) if (c.id.equals(id)) return c;
        return null;
    }

    public ChannelDef fallback() {
        for (ChannelDef c : channels) if (c.isFallback()) return c;
        return channels.get(0);
    }

    /**
     * Los patrones son punto de partida: cada servidor formatea el chat distinto.
     * Ajústalos en config/hoennascension.json y usa /hoennascension reload.
     */
    private static List<ChannelDef> defaultChannels() {
        List<ChannelDef> l = new ArrayList<>();
        l.add(new ChannelDef("general", "General", "", "#BFD4FF"));
        l.add(new ChannelDef("teleport", "Teleport",
                "(has requested to teleport|wants to teleport to you|solicitud de teletransporte|quiere teletransportarse)",
                "#5CFFE0").popup("orb").actions("/tpaccept", "/tpdeny"));
        l.add(new ChannelDef("private", "Privado",
                "(\\[pm\\]|whispers to you|te susurra|->\\s*(me|you|yo)\\b)",
                "#A481DE").popup("orb"));
        l.add(new ChannelDef("clan", "Clan", "\\[(clan|clán)\\]", "#47B5F8"));
        l.add(new ChannelDef("legendary", "Legendarios", "(legendary|legendario)", "#EC7D8B").popup("levelup"));
        l.add(new ChannelDef("mega", "Mega", "\\bmega\\b", "#FF5A3C").popup("levelup"));
        l.add(new ChannelDef("trade", "Mercado", "\\b(gts|wonder ?trade|intercambio)\\b", "#FFC247"));
        return l;
    }
}