package dev.hoennascension.core;

public final class ChatEntry {
    public long time;
    public String channel;
    public String text;
    public boolean mention;

    public ChatEntry() {}

    public ChatEntry(long time, String channel, String text, boolean mention) {
        this.time = time;
        this.channel = channel;
        this.text = text;
        this.mention = mention;
    }
}