package dev.hoennascension.core;

import dev.hoennascension.HoennAscensionClient;
import dev.hoennascension.config.ChannelDef;
import dev.hoennascension.config.HoennConfig;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/** Clasifica cada mensaje entrante en un canal y dispara popups/sonidos. */
public final class MessageRouter {
    private MessageRouter() {}

    /** @return true si el mensaje debe seguir apareciendo en el chat vanilla. */
    public static boolean accept(class_2561 text) {
        String plain = text.getString().trim();
        if (plain.isEmpty()) return true;

        HoennConfig cfg = HoennConfig.get();
        ChannelDef ch = route(cfg, plain);
        boolean mention = cfg.mentionHighlight && mentions(cfg, plain);

        HoennAscensionClient.STORE.add(new ChatEntry(System.currentTimeMillis(), ch.id, plain, mention));

        if (!ch.muted && (ch.popup || mention)) {
            if (cfg.popups) HoennAscensionClient.POPUPS.push(ch.popup ? ch.name : "@", plain, ch);
            String snd = ch.sound;
            if ((snd == null || snd.equals("none")) && mention) snd = "orb";
            HoennAscensionClient.playSound(snd);
        }
        return !ch.hideFromVanilla;
    }

    private static ChannelDef route(HoennConfig cfg, String plain) {
        for (ChannelDef c : cfg.channels) {
            if (c.matches(plain)) return c;
        }
        return cfg.fallback();
    }

    private static boolean mentions(HoennConfig cfg, String plain) {
        String lower = plain.toLowerCase(Locale.ROOT);
        class_310 mc = class_310.method_1551();
        if (mc.method_1548() != null) {
            String me = mc.method_1548().method_1676();
            if (me != null && !me.isEmpty()) {
                String meLower = me.toLowerCase(Locale.ROOT);
                if (lower.contains(meLower) && !lower.startsWith("<" + meLower + ">")) return true;
            }
        }
        for (String w : cfg.highlightWords) {
            if (w != null && !w.isBlank() && lower.contains(w.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }
}