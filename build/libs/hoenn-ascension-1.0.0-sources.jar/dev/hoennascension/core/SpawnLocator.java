package dev.hoennascension.core;

import dev.hoennascension.HoennAscensionClient;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

/**
 * Cuando un aviso de aparición no trae coordenadas, intenta localizar al Pokémon entre las entidades que el
 * cliente tiene cargadas cerca de ti (solo las cercanas llegan al cliente) y rellena sus coordenadas y distancia.
 */
public final class SpawnLocator {
    private static final class Pending {
        ChatEntry entry;
        String pokemon;
        long deadline;
    }

    private static final List<Pending> PENDING = new ArrayList<>();

    private SpawnLocator() {}

    public static void watch(ChatEntry entry, String pokemon) {
        if (pokemon == null || pokemon.isBlank()) return;
        Pending p = new Pending();
        p.entry = entry;
        p.pokemon = pokemon;
        p.deadline = System.currentTimeMillis() + 6000;
        PENDING.add(p);
        while (PENDING.size() > 8) PENDING.remove(0);
    }

    private static String norm(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static class_1297 find(class_310 mc, String pokemon) {
        String want = norm(pokemon);
        if (want.length() < 3) return null;
        class_1297 best = null;
        double bestD = Double.MAX_VALUE;
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e == mc.field_1724) continue;
            class_2960 id = class_7923.field_41177.method_10221(e.method_5864());
            if (!"cobblemon".equals(id.method_12836())) continue;
            String name = norm(e.method_5477().getString());
            if (name.length() < 3 || !(name.contains(want) || want.contains(name))) continue;
            double d = e.method_5858(mc.field_1724);
            if (d < bestD) {
                best = e;
                bestD = d;
            }
        }
        return best;
    }

    public static void tick() {
        if (PENDING.isEmpty()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) {
            PENDING.clear();
            return;
        }
        long now = System.currentTimeMillis();
        boolean changed = false;
        Iterator<Pending> it = PENDING.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            class_1297 found = find(mc, p.pokemon);
            if (found != null) {
                ChatEntry e = p.entry;
                e.hasPos = true;
                e.x = (int) Math.floor(found.method_23317());
                e.y = (int) Math.floor(found.method_23318());
                e.z = (int) Math.floor(found.method_23321());
                e.dist = (int) Math.round(Math.hypot(mc.field_1724.method_23317() - found.method_23317(), mc.field_1724.method_23321() - found.method_23321()));
                changed = true;
                it.remove();
            } else if (now > p.deadline) {
                it.remove();
            }
        }
        if (changed) HoennAscensionClient.STORE.touch();
    }
}