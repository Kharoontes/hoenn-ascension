package dev.hoennascension.ui;

import dev.hoennascension.HoennAscensionClient;
import dev.hoennascension.config.ChannelDef;
import dev.hoennascension.config.HoennConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;

/** Pantalla de ajustes (accesible desde Mod Menu y desde el engranaje del panel). */
public final class HoennConfigScreen extends class_437 {
    private static final String[] ANCHORS = {"top_left", "top_right", "bottom_left", "bottom_right"};
    private static final int ROW_H = 24;

    private final class_437 parent;
    private final List<class_339> entries = new ArrayList<>();
    private int scroll = 0;
    private int count = 0;
    private int colW;
    private int left;

    public HoennConfigScreen(class_437 parent) {
        super(class_2561.method_43471("hoennascension.config.title"));
        this.parent = parent;
    }

    private int top() { return 34; }
    private int bottom() { return field_22790 - 34; }

    private static class_2561 label(String key, String value) {
        return class_2561.method_43471(key).method_27693(": " + value);
    }

    private static String onOff(boolean b) {
        return class_5244.method_36134(b).getString();
    }

    private static String anchorName(String a) {
        return class_2561.method_43471("hoennascension.anchor." + a).getString();
    }

    private static String nextAnchor(String current) {
        for (int i = 0; i < ANCHORS.length; i++) {
            if (ANCHORS[i].equalsIgnoreCase(current)) return ANCHORS[(i + 1) % ANCHORS.length];
        }
        return ANCHORS[0];
    }

    private <T extends class_339> T add(T w) {
        w.method_46421(left + (count % 2) * (colW + 8));
        entries.add(w);
        method_37063(w);
        count++;
        return w;
    }

    private void addButton(String key, Supplier<String> value, Runnable onClick) {
        class_4185 b = class_4185.method_46430(label(key, value.get()), btn -> {
            onClick.run();
            btn.method_25355(label(key, value.get()));
        }).method_46434(0, 0, colW, 20).method_46431();
        add(b);
    }

    private void addToggle(String key, BooleanSupplier get, java.util.function.Consumer<Boolean> set) {
        addButton(key, () -> onOff(get.getAsBoolean()), () -> set.accept(!get.getAsBoolean()));
    }

    private void addSlider(String key, double min, double max, double step, double current,
                           DoubleFunction<String> fmt, DoubleConsumer setter) {
        add(new OptSlider(colW, key, min, max, step, current, fmt, setter));
    }

    /** Interruptor por canal: ocultar sus mensajes del chat normal de Minecraft. */
    private void addChannelHide(ChannelDef ch) {
        Supplier<class_2561> txt = () -> class_2561.method_43469("hoennascension.opt.hideChannel", ch.name)
                .method_27693(": " + onOff(ch.hideFromVanilla));
        class_4185 b = class_4185.method_46430(txt.get(), btn -> {
            ch.hideFromVanilla = !ch.hideFromVanilla;
            btn.method_25355(txt.get());
        }).method_46434(0, 0, colW, 20).method_46431();
        add(b);
    }

    @Override
    protected void method_25426() {
        HoennConfig cfg = HoennConfig.get();
        entries.clear();
        count = 0;
        colW = Math.max(100, Math.min(200, (field_22789 - 24) / 2));
        left = (field_22789 - (colW * 2 + 8)) / 2;

        DoubleFunction<String> pct = v -> Math.round(v * 100) + "%";
        DoubleFunction<String> num = v -> String.valueOf((int) Math.round(v));
        DoubleFunction<String> secs = v -> (int) Math.round(v) + " s";

        addButton("hoennascension.opt.theme", () -> Theme.byId(cfg.theme).label,
                () -> cfg.theme = Theme.byId(cfg.theme).next().id);
        addSlider("hoennascension.opt.menuOpacity", 0.15, 1.0, 0.05, cfg.menuOpacity, pct,
                v -> cfg.menuOpacity = (float) v);
        addToggle("hoennascension.opt.timestamps", () -> cfg.timestamps, v -> cfg.timestamps = v);
        addToggle("hoennascension.opt.showLogo", () -> cfg.showLogo, v -> cfg.showLogo = v);
        addToggle("hoennascension.opt.showBanner", () -> cfg.showBanner, v -> cfg.showBanner = v);
        addToggle("hoennascension.opt.sidebar", () -> cfg.sidebarCollapsed, v -> cfg.sidebarCollapsed = v);

        addToggle("hoennascension.opt.hudPinned", () -> cfg.hudPinned, v -> cfg.hudPinned = v);
        addButton("hoennascension.opt.hudAnchor", () -> anchorName(cfg.hudAnchor),
                () -> cfg.hudAnchor = nextAnchor(cfg.hudAnchor));
        addSlider("hoennascension.opt.hudLines", 1, 20, 1, cfg.hudLines, num, v -> cfg.hudLines = (int) v);
        addSlider("hoennascension.opt.hudWidth", 120, 600, 10, cfg.hudWidth, num, v -> cfg.hudWidth = (int) v);
        addSlider("hoennascension.opt.hudOpacity", 0.05, 1.0, 0.05, cfg.hudOpacity, pct,
                v -> cfg.hudOpacity = (float) v);
        addSlider("hoennascension.opt.hudFade", 2, 60, 1, cfg.hudFadeSeconds, secs,
                v -> cfg.hudFadeSeconds = (int) v);
        addToggle("hoennascension.opt.hudAlways", () -> cfg.hudAlwaysVisible, v -> cfg.hudAlwaysVisible = v);

        addToggle("hoennascension.opt.popups", () -> cfg.popups, v -> cfg.popups = v);
        addSlider("hoennascension.opt.popupSeconds", 2, 30, 1, cfg.popupSeconds, secs,
                v -> cfg.popupSeconds = (int) v);
        addSlider("hoennascension.opt.actionSeconds", 5, 60, 1, cfg.actionPopupSeconds, secs,
                v -> cfg.actionPopupSeconds = (int) v);
        addToggle("hoennascension.opt.mentions", () -> cfg.mentionHighlight, v -> cfg.mentionHighlight = v);
        addSlider("hoennascension.opt.history", 20, 2000, 20, cfg.historyPerChannel, num,
                v -> cfg.historyPerChannel = (int) v);

        // Chat normal de Minecraft
        addToggle("hoennascension.opt.hideAll", () -> cfg.hideAllFromVanilla, v -> cfg.hideAllFromVanilla = v);
        addToggle("hoennascension.opt.hideFeedback", () -> cfg.hideCommandFeedback, v -> cfg.hideCommandFeedback = v);
        addSlider("hoennascension.opt.feedbackSeconds", 1, 10, 1, cfg.commandFeedbackSeconds, secs,
                v -> cfg.commandFeedbackSeconds = (int) v);
        for (ChannelDef ch : cfg.channels) addChannelHide(ch);

        addSlider("hoennascension.opt.minWidth", 240, 500, 10, cfg.windowMinWidth, num, v -> cfg.windowMinWidth = (int) v);
        addSlider("hoennascension.opt.minHeight", 140, 400, 10, cfg.windowMinHeight, num, v -> cfg.windowMinHeight = (int) v);
        addSlider("hoennascension.opt.maxWidth", 400, 1200, 20, cfg.windowMaxWidth, num, v -> cfg.windowMaxWidth = (int) v);
        addSlider("hoennascension.opt.maxHeight", 300, 900, 20, cfg.windowMaxHeight, num, v -> cfg.windowMaxHeight = (int) v);

        addToggle("hoennascension.opt.pillAlways", () -> cfg.pillAlwaysVisible, v -> cfg.pillAlwaysVisible = v);
        addButton("hoennascension.opt.pillAnchor", () -> anchorName(cfg.minimizedAnchor), () -> {
            cfg.minimizedAnchor = nextAnchor(cfg.minimizedAnchor);
            cfg.pillXr = -1f;
            cfg.pillYr = -1f;
        });
        add(class_4185.method_46430(class_2561.method_43471("hoennascension.opt.resetLayout"), btn -> {
            cfg.resetLayout();
            cfg.save();
        }).method_46434(0, 0, colW, 20).method_46431());
        add(class_4185.method_46430(class_2561.method_43471("hoennascension.opt.clearHistory"),
                btn -> HoennAscensionClient.STORE.clear()).method_46434(0, 0, colW, 20).method_46431());

        method_37063(class_4185.method_46430(class_5244.field_24334, btn -> method_25419())
                .method_46434(field_22789 / 2 - 100, field_22790 - 26, 200, 20).method_46431());

        applyScroll();
    }

    private int maxScroll() {
        int rows = (count + 1) / 2;
        return Math.max(0, rows * ROW_H - (bottom() - top()));
    }

    private void applyScroll() {
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
        for (int i = 0; i < entries.size(); i++) {
            class_339 w = entries.get(i);
            int y = top() + (i / 2) * ROW_H - scroll;
            w.method_46419(y);
            boolean inside = y >= top() - 2 && y + w.method_25364() <= bottom() + 2;
            w.field_22764 = inside;
            w.field_22763 = inside;
        }
    }

    @Override
    public boolean method_25401(double mx, double my, double horizontal, double vertical) {
        if (vertical != 0) {
            scroll -= (int) (vertical * 14);
            applyScroll();
            return true;
        }
        return super.method_25401(mx, my, horizontal, vertical);
    }

    @Override
    public void method_25394(class_332 c, int mx, int my, float delta) {
        super.method_25394(c, mx, my, delta);
        c.method_27534(field_22793, field_22785, field_22789 / 2, 14, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    @Override
    public void method_25432() {
        HoennConfig.get().save();
    }

    /** Deslizador genérico con rango, paso y formato propios. */
    private static final class OptSlider extends class_357 {
        private final String key;
        private final double min, max, step;
        private final DoubleFunction<String> fmt;
        private final DoubleConsumer setter;

        OptSlider(int w, String key, double min, double max, double step, double current,
                  DoubleFunction<String> fmt, DoubleConsumer setter) {
            super(0, 0, w, 20, class_2561.method_43473(), (current - min) / (max - min));
            this.key = key;
            this.min = min;
            this.max = max;
            this.step = step;
            this.fmt = fmt;
            this.setter = setter;
            method_25346();
        }

        private double current() {
            double v = min + field_22753 * (max - min);
            if (step > 0) v = Math.round(v / step) * step;
            return Math.max(min, Math.min(max, v));
        }

        @Override
        protected void method_25346() {
            if (fmt == null) return;
            method_25355(class_2561.method_43471(key).method_27693(": " + fmt.apply(current())));
        }

        @Override
        protected void method_25344() {
            setter.accept(current());
        }
    }
}