package dev.hoennascension.ui;

import dev.hoennascension.HoennAscensionClient;
import dev.hoennascension.config.ChannelDef;
import dev.hoennascension.config.HoennConfig;
import dev.hoennascension.core.ChatEntry;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;

/** Mini panel anclado: últimas líneas del chat, con desvanecido por antigüedad. */
public final class HudOverlay {
    private HudOverlay() {}

    private record HudLine(class_5481 text, float alpha, int rgb) {}

    public static void render(class_332 c) {
        class_310 mc = class_310.method_1551();
        HoennConfig cfg = HoennConfig.get();
        if (!cfg.hudPinned || mc.field_1690.field_1842 || mc.field_1755 != null || mc.field_1724 == null) return;

        class_327 tr = mc.field_1772;
        Theme th = Theme.byId(cfg.theme);
        long now = System.currentTimeMillis();
        long fadeMs = cfg.hudFadeSeconds * 1000L;
        int sw = c.method_51421();
        int sh = c.method_51443();
        int hudW = Math.max(100, Math.min(cfg.hudWidth, sw - 12));
        int wrapW = hudW - 14;

        List<ChatEntry> entries = HoennAscensionClient.STORE.view(cfg.hudChannel, "", cfg.hudLines);
        List<HudLine> lines = new ArrayList<>();
        for (ChatEntry e : entries) {
            float a = 1f;
            if (!cfg.hudAlwaysVisible) {
                long age = now - e.time;
                if (age > fadeMs) continue;
                long left = fadeMs - age;
                if (left < 2000) a = left / 2000f;
            }
            ChannelDef ch = cfg.channel(e.channel);
            int rgb = ch != null ? ch.rgb() : 0xFFFFFF;
            class_2561 t = class_2561.method_43473()
                    .method_10852(class_2561.method_43470("• ").method_10862(class_2583.field_24360.method_36139(rgb)))
                    .method_10852(class_2561.method_43470(e.text));
            for (class_5481 ot : tr.method_1728(t, wrapW)) lines.add(new HudLine(ot, a, rgb));
        }
        if (lines.isEmpty()) return;
        if (lines.size() > cfg.hudLines) lines = lines.subList(lines.size() - cfg.hudLines, lines.size());

        float maxA = 0f;
        for (HudLine l : lines) maxA = Math.max(maxA, l.alpha());

        int h = lines.size() * 10 + 8;
        int w = hudW;
        String anchor = cfg.hudAnchor.toLowerCase();
        int x = anchor.contains("right") ? sw - w - 6 : 6;
        int y = anchor.contains("bottom") ? sh - h - 50 : 6;

        float bg = Math.min(1f, cfg.hudOpacity * th.opacityMul) * maxA;
        c.method_25296(x, y, x + w, y + h, Gfx.alpha(th.bgTop, bg), Gfx.alpha(th.bgBottom, bg));
        // Barra vertical con los tres tonos del tema
        c.method_25296(x, y, x + 2, y + h / 2, Gfx.alpha(th.edgeA, maxA), Gfx.alpha(th.edgeB, maxA));
        c.method_25296(x, y + h / 2, x + 2, y + h, Gfx.alpha(th.edgeB, maxA), Gfx.alpha(th.edgeC, maxA));

        int ty = y + 4;
        for (HudLine l : lines) {
            int col = Gfx.alpha(th.text, l.alpha());
            if ((col >>> 24) > 3) c.method_51430(tr, l.text(), x + 7, ty, col, !th.light);
            ty += 10;
        }
    }
}