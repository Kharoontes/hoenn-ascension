package dev.hoennascension.ui;

import dev.hoennascension.HoennAscensionClient;
import dev.hoennascension.config.ChannelDef;
import dev.hoennascension.config.HoennConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;

/** Notificaciones apiladas arriba a la derecha, con acciones aceptar/rechazar opcionales. */
public final class PopupManager {
    private static final int MAX_W = 196;
    private static final int MAX_VISIBLE = 4;

    private static final class Popup {
        String tag;
        String icon;
        String title;
        String body;
        String accept;
        String deny;
        int rgb;
        long born;
        long life;

        boolean actionable() {
            return accept != null && !accept.isBlank();
        }
    }

    private final List<Popup> popups = new ArrayList<>();

    public void push(String title, String body, ChannelDef ch) {
        HoennConfig cfg = HoennConfig.get();
        Popup p = new Popup();
        p.title = title;
        p.body = body.length() > 140 ? body.substring(0, 137) + "..." : body;
        p.rgb = ch.rgb();
        p.icon = ch.iconName();
        p.born = System.currentTimeMillis();
        if (ch.isActionable()) {
            p.accept = ch.acceptCommand;
            p.deny = ch.denyCommand;
            p.life = cfg.actionPopupSeconds * 1000L;
        } else {
            p.life = cfg.popupSeconds * 1000L;
        }
        popups.add(p);
        while (popups.size() > 8) popups.remove(0);
    }

    /** Aviso simple con etiqueta: uno nuevo con la misma etiqueta sustituye al anterior. */
    public void notice(String tag, String title, String body, int rgb, int seconds) {
        notice(tag, tag, title, body, rgb, seconds);
    }

    /** Aviso con etiqueta e icono propio (el nombre de un icono de Icons). */
    public void notice(String tag, String icon, String title, String body, int rgb, int seconds) {
        popups.removeIf(p -> tag.equals(p.tag));
        Popup p = new Popup();
        p.tag = tag;
        p.icon = icon;
        p.title = title;
        p.body = body.length() > 140 ? body.substring(0, 137) + "..." : body;
        p.rgb = rgb;
        p.born = System.currentTimeMillis();
        p.life = seconds * 1000L;
        popups.add(p);
    }

    public void clear() {
        popups.clear();
    }

    /** Se llama cada tick: caducidad y teclas de acción. */
    public void tick(class_310 mc) {
        long now = System.currentTimeMillis();
        popups.removeIf(p -> now - p.born > p.life);

        while (HoennAscensionClient.ACCEPT.method_1436()) runAction(mc, true);
        while (HoennAscensionClient.DENY.method_1436()) runAction(mc, false);
    }

    private void runAction(class_310 mc, boolean accept) {
        Popup target = null;
        for (int i = popups.size() - 1; i >= 0; i--) {
            if (popups.get(i).actionable()) {
                target = popups.get(i);
                break;
            }
        }
        if (target == null || mc.field_1724 == null) return;
        String cmd = accept ? target.accept : target.deny;
        popups.remove(target);
        if (cmd == null || cmd.isBlank()) return;
        mc.field_1724.field_3944.method_45730(cmd.startsWith("/") ? cmd.substring(1) : cmd);
    }

    /** Dibujo desde el HUD: cuando el panel está abierto, lo dibuja él mismo encima de su fondo. */
    public void render(class_332 c) {
        if (class_310.method_1551().field_1755 instanceof CommsScreen) return;
        draw(c);
    }

    public void renderOverScreen(class_332 c) {
        draw(c);
    }

    private void draw(class_332 c) {
        if (popups.isEmpty()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;
        HoennConfig cfg = HoennConfig.get();
        Theme th = Theme.byId(cfg.theme);
        class_327 tr = mc.field_1772;
        int sw = c.method_51421();
        int W = Math.max(100, Math.min(MAX_W, sw - 12));
        long now = System.currentTimeMillis();

        int start = Math.max(0, popups.size() - MAX_VISIBLE);
        int y = 6;
        for (int i = start; i < popups.size(); i++) {
            Popup p = popups.get(i);
            long age = now - p.born;
            long left = p.life - age;

            float slide = Math.min(1f, age / 250f);
            slide = 1f - (1f - slide) * (1f - slide);
            float fade = left < 300 ? Math.max(0f, left / 300f) : 1f;
            int x = sw - W - 6 + (int) ((1f - slide) * (W + 12));

            List<class_5481> lines = tr.method_1728(class_2561.method_43470(p.body), W - 18);
            int shown = Math.min(2, lines.size());
            int h = 20 + shown * 10 + (p.actionable() ? 12 : 0);

            Gfx.panel(c, x, y, W, h, th, Math.min(1f, cfg.menuOpacity + 0.2f) * fade);
            // Barra lateral del color del canal
            c.method_25294(x + 1, y + 1, x + 4, y + h - 1, Gfx.rgb(p.rgb, fade));
            if (!Icons.draw(c, p.icon, x + 6, y + 3, 12, fade)) Gfx.diamond(c, x + 12, y + 8, 3, Gfx.rgb(p.rgb, fade));
            c.method_51433(tr, p.title, x + 22, y + 5, Gfx.alpha(th.text, fade), !th.light);

            int ty = y + 16;
            for (int l = 0; l < shown; l++) {
                c.method_51430(tr, lines.get(l), x + 10, ty, Gfx.alpha(th.text, fade), false);
                ty += 10;
            }
            if (p.actionable()) {
                class_2561 acc = class_2561.method_43470("[").method_10852(HoennAscensionClient.ACCEPT.method_16007())
                        .method_27693("] ").method_10852(class_2561.method_43471("hoennascension.popup.accept"));
                class_2561 den = class_2561.method_43470("[").method_10852(HoennAscensionClient.DENY.method_16007())
                        .method_27693("] ").method_10852(class_2561.method_43471("hoennascension.popup.deny"));
                c.method_51439(tr, acc, x + 10, ty + 1, Gfx.alpha(0xFF22B25F, fade), false);
                c.method_51439(tr, den, x + 20 + tr.method_27525(acc), ty + 1, Gfx.alpha(0xFFE0463F, fade), false);
            }
            y += h + 4;
        }
    }
}