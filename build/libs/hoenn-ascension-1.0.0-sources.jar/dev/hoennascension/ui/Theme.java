package dev.hoennascension.ui;

/**
 * Paletas tomadas de los tonos del logo: azul profundo/eléctrico (Kyogre),
 * violeta central (equilibrio) y rojo/naranja (Groudon).
 */
public enum Theme {
    KYOGRE("kyogre", "Kyogre",
            0xFF06185A, 0xFF0F4AA8,
            0xFF0C3ED8, 0xFF2F8CF0, 0xFF47B5F8),
    GROUDON("groudon", "Groudon",
            0xFF3A0608, 0xFF8A1410,
            0xFFC20207, 0xFFE8451F, 0xFFFFA24A),
    PRIMAL("primal", "Primal",
            0xFF16086A, 0xFF3A1688,
            0xFF0C3ED8, 0xFF8A55E8, 0xFFE0202A);

    public final String id;
    public final String label;
    public final int bgTop, bgBottom;
    /** Borde: izquierda, centro, derecha. */
    public final int edgeA, edgeB, edgeC;
    public final int text = 0xFFE8EEFF;
    public final int muted = 0xFF8A94C0;

    Theme(String id, String label, int bgTop, int bgBottom, int a, int b, int c) {
        this.id = id;
        this.label = label;
        this.bgTop = bgTop;
        this.bgBottom = bgBottom;
        this.edgeA = a;
        this.edgeB = b;
        this.edgeC = c;
    }

    /** Color del degradado horizontal en t = 0..1 */
    public int edgeAt(float t) {
        if (t < 0.5f) return Gfx.lerp(edgeA, edgeB, t * 2f);
        return Gfx.lerp(edgeB, edgeC, (t - 0.5f) * 2f);
    }

    public static Theme byId(String id) {
        for (Theme t : values()) if (t.id.equalsIgnoreCase(id)) return t;
        return PRIMAL;
    }

    public Theme next() {
        Theme[] v = values();
        return v[(ordinal() + 1) % v.length];
    }
}